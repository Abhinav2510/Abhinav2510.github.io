import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class DBSettings {
    private String DBURL="jdbc:mysql://latcs7.cs.latrobe.edu.au:3306/18738982";
    private String userName="18738982";
    private String password="QWy9fKzktEU8xrXm7jpk";

    public String getDBURL() {
        return DBURL;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
}
